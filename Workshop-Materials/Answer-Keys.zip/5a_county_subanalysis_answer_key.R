#----------------------------------------------------------------#
#               2025 CSTE Applied Trend Analysis in R            #
#   Subgroup Analysis Strategies - Guided Practice Answer Key    #
# Authors: Johns Hopkins Surveillance and Outbreak Response Team #
#----------------------------------------------------------------#

# In this guided practice session, we will ask you to use what you learned in
# the R walkthrough and apply it to a slightly altered scenario to orient
# to the code. We will leave questions and blanks (____) in the code that
# you will have to fill in to complete the actions. Refer to the
# R walkthrough scripts for guidance.


#---- Setup #----

# List of package names as characters
pkgs <- c("tidyverse", "ISOweek", "excessmort", "ggpubr", "openxlsx")

# Installing any of the packages that you don't already have
install.packages(setdiff(pkgs, rownames(installed.packages())))

# Loading all the packages
lapply(
  pkgs,
  library,
  character.only = TRUE,
  quietly = TRUE,
  verbose = FALSE
)

# Read in mortality data set
mort.dat <- read_csv("linelist_2010-2020_mi.csv") %>%
  mutate(isoweek = paste0(isoyear(date), "-W", sprintf("%02d", isoweek(date)), "-1")) %>%
  mutate(isodate = ISOweek2date(isoweek)) %>%
  select(-date) %>%
  filter(isoweek != "2009-W53-1" & isoweek != "2020-W53-1")

# Define the pandemic period (when we don't want to calculate expected deaths)
pandemic.dates <- seq.Date(as.Date("2020-03-10"), as.Date("2020-12-31"), by = "day")


#---- Sub-analysis by County #----

# The full dataset 'mort.dat' is also recorded at the county level, so let's see
# if there were any big differences in 2020 excess deaths by county

# For county-specific rates of excess mortality, we'll use the same type of setup
# for demographic data, but this time we have a row for every county's population
# in every year. This is a little different from analyzing specific causes of death
# since only residents in a given county are considered at-risk of death in that
# category. Put another way, we want to calculate rates of death in each county
# from the count level data that we have.

# Read in county-level demographic data
demo.county.in <- read_csv("demo_by_year_by_county_2010-2020_MI.csv")

# But since there are 83 counties in Michigan, let's make things a little easier
# on ourselves and select four counties to look at. How about two urban and two
# rural? Let's look at Wayne County (Detroit), Kent County (Grand Rapids),
# Marquette (in the Upper Pensinsula), and Lapeer (outside Detroit).

### Question: Filter to these counties
mort.dat.co <- mort.dat %>%
  filter(
    county %in% c(
      "Wayne County, MI",
      "Kent County, MI",
      "Marquette County, MI",
      "Lapeer County, MI"
    )
  )

### Question: Filter the demographic data the same way
demo.county.in.sub <- demo.county.in %>%
  filter(
    county %in% c(
      "Wayne County, MI",
      "Kent County, MI",
      "Marquette County, MI",
      "Lapeer County, MI"
    )
  )

# We need to take that table of annual population by county and create a long
# dataframe with daily population.
### Question: How should you set this code up? What type of extrapolation do
### you think should be performed?
demo.county <- approx_demographics(
  demo.county.in.sub,
  first_day = min(mort.dat$isodate),
  last_day = max(mort.dat$isodate),
  by = "county",
  extrapolation.type = "linear"
)

# Count how many deaths occurred in each county, each week
### Question: How should the 'compute_counts()' function be completed to count
### weekly deaths in each county?
county.counts <- compute_counts(
  dat = mort.dat.co,
  demo = demo.county,
  date = "isodate",
  by = "county"
)

### Question: How can we 'split' the counts of weekly deaths into a list of dataframes
### with a separate dataframe for each county?
county.counts.ls <- split(county.counts, f = county.counts$county)

# Run the excess model function on each item in the list using 'lapply'
weekly.xs.county <- lapply(county.counts.ls, # Define a new function where the variable 'x' will stand in for each county's
                           # weekly counts of deaths
                           function(x) {
                             return(
                               x %>%
                                 ### Question: How would you set up the 'excess_model' function?
                                 excess_model(
                                   exclude = pandemic.dates,
                                   start = min(.$date),
                                   end = max(.$date),
                                   knots.per.year = 12,
                                   include.trend = FALSE,
                                   frequency = 52,
                                   model = "quasipoisson",
                                   alpha = 0.05,
                                   keep.counts = TRUE
                                 )
                             )
                           })

### Question: If we want to restructure the model ouput to plot a time series
### of observed vs. expected deaths (including a 95% confidence interval of the
### expected weekly count), how would you create an 'lapply' loop to drop the
### columns we don't need and calculate a 95% CI?

weekly.county.ts <- lapply(weekly.xs.county, # Define a function where the variable 'x' will stand in for each county's
                           # excess model output (stored in the 'weekly.xs.county' object)
                           function(x) {
                             x <- bind_cols(x[c("date", "observed", "expected", "fitted", "log_expected_se")]) %>%
                               mutate(
                                 exp.l95 = exp(log(expected) - qnorm(1 - (.05 / 2)) * log_expected_se),
                                 exp.u95 = exp(log(expected) + qnorm(1 - (.05 / 2)) * log_expected_se)
                               )
                           })

# Efficiently plot excess death by county using an 'mapply' loop to loop over
# the time series data for each county created in the step above and the names of
# each county
xs.county.plots <- mapply(
  # Define a function where the variable 'x' will stand in for each county's
  # times series of observed and expected deaths and 'y' will stand in for the
  # names of each corresponding county
  function(x, y) {
    ### Question: filter for only dates in 2020
    x <- x %>%
      filter(date > make_date(2020, 01, 01)) %>%
      ### Question: Restructure the data from wide to long, creating a new variable
      ### called 'class' that describes whether the value is an observed or
      ### expected weekly count.
      pivot_longer(
        cols = c(observed:expected),
        names_to = "class",
        values_to = "value"
      ) %>%
      mutate(class = factor(
        class,
        levels = c("observed", "expected"),
        labels = c("Observed", "Expected")
      ))
    
    return(
      ### Question: Create a time series line plot with a ribbon plot of the upper
      ### and lower 95% confidence interval
      ggplot(x, aes(
        x = date, y = value, col = class
      )) +
        geom_line() +
        geom_ribbon(
          data = x %>% filter(class == "Expected"),
          aes(ymin = exp.l95, ymax = exp.u95),
          fill = NA,
          lty = 2
        ) +
        scale_x_date(
          date_breaks = "1 month",
          date_minor_breaks = "1 week",
          date_labels = "%b %Y"
        ) +
        theme(
          axis.text.x = element_text(angle = 45, hjust = 1),
          panel.grid.minor = element_blank()
        ) +
        xlab("Date") +
        ylab("Weekly Death Count") +
        labs(
          col = NULL,
          title = "Excess Mortality 2020",
          subtitle = y
        )
    )
  },
  ### Question: Define what the variables 'x' and 'y' refer to in your function.
  x = weekly.county.ts,
  y = names(weekly.county.ts),
  SIMPLIFY = FALSE
)

### Question: Which county experienced the greatest relative and/or absolute excess
### mortality during the first wave of COVID-19? What about the during the B.1.1.7
### "Alpha" wave in late 2020?
### Answer: Wayne County, MI experienced the highest excess mortality during the
### initial "wild type" wave in March-May, 2020 and experienced elevated mortality
### throughout the remainder of 2020. Lapeer and Marquette Counties (both more rural
### and with lower population) experienced sporadic levels of mortality that wavered
### above and below expected values. Kent County experienced less excess mortality
### during the initial wave but significant excess mortality during the B.1.1.7
### variant dominiant wave in the winter of 2020-2021.

# Save the figures for each county
mapply(function(x, y) {
  ggsave(
    y,
    plot = x,
    width = 6.5,
    height = 3,
    units = "in",
    dpi = 300
  )
},
x = xs.county.plots,
y = paste0("excess_", gsub(" ", "_", gsub(
  " & ", "-", names(xs.county.plots)
)), "_deaths.png"))

# Create a table of statistics for each county
county.table <- mapply(
  # Define a function where the variable 'x' refers to weekly counts of deaths by
  # county and the variable 'y' refers to the names of each corresponding county.
  function(x, y) {
    return(
      ### Question: Calculate excess mortality in 2020 for each county
      x %>%
        ### Question: Run the 'excess_model()'
        excess_model(
          exclude = pandemic.dates,
          intervals = list(pandemic.dates),
          knots.per.year = 12,
          include.trend = TRUE,
          model = "quasipoisson",
          alpha = 0.05
        ) %>%
        ### Question: Calculate standard error
        mutate(se = sd / sqrt(observed)) %>%
        ### Question: Use the standard error you calculated to calculate confidence
        ### intervals of excess mortality
        mutate(
          excess.l95 = excess - qnorm(1 - (.05 / 2)) * se,
          excess.u95 = excess + qnorm(1 - (.05 / 2)) * se
        ) %>%
        ### Question: Calculate mortality ratios and confidence intervals
        mutate(
          mr = observed / expected,
          mr.l95 = observed / (expected + qnorm(1 - (.05 / 2)) * se),
          mr.u95 = observed / (expected - qnorm(1 - (.05 / 2)) * se)
        ) %>%
        # Renaming
        mutate(cause = y) %>%
        relocate(cause) %>%
        ### Question: Calculate the rate of excess mortality
        mutate(xs_rate = obs_death_rate - exp_death_rate)
    )
  },
  x = county.counts.ls,
  y = names(county.counts.ls),
  SIMPLIFY = FALSE
) %>%
  bind_rows()

### Question: Which county(ies) experience significant excess mortality during
### the COVID-19 pandemic in 2020?
### Question: How many more people died during the 2020 COVID-19
### pandemic than was expected in Lapeer County?
### Answer: Looking at which counties have excess death confidence intervals that
### do not overlap the null association value (in this case, zero), we can see that
### Kent, Lapeer, and Wayne Counties all experienced significantly more deaths than
### expected, while Marquette County did not experience significant more or fewer
### than expected based on data from 2011-2019.
### Answer: Looking at the column titled 'excess', we can see that 65.67 (or since
### deaths cannot be fractional, 66) deaths occurred in excess of what would have
### been expected.

# Save the table as an Excel file
write.xlsx(county.table, "excess_deaths_by_county.xlsx", asTable = TRUE)
