#----------------------------------------------------------------#
#               2025 CSTE Applied Trend Analysis in R            #
#   Subgroup Analysis Strategies - Age Group Answer Key          #
# Authors: Johns Hopkins Surveillance and Outbreak Response Team #
#----------------------------------------------------------------#

# In this guided practice session, we will ask you to use what you learned in
# the R walkthrough and apply it to a slightly altered scenario to orient
# to the code. We will leave questions and blanks (____) in the code that
# you will have to fill in to complete the actions. Refer to the
# R walkthrough scripts for guidance.


#---- Setup #----

# List of package names as characters
pkgs <- c("tidyverse", "ISOweek", "excessmort", "ggpubr", "openxlsx")

# Installing any of the packages that you don't already have
install.packages(setdiff(pkgs, rownames(installed.packages())))

# Loading all the packages
lapply(
  pkgs,
  library,
  character.only = TRUE,
  quietly = TRUE,
  verbose = FALSE
)

# Read in mortality data set
mort.dat <- read_csv("linelist_2010-2020_mi.csv") %>%
  mutate(isoweek = paste0(isoyear(date), "-W", sprintf("%02d", isoweek(date)), "-1")) %>%
  mutate(isodate = ISOweek2date(isoweek)) %>%
  select(-date) %>%
  filter(isoweek != "2009-W53-1" & isoweek != "2020-W53-1")

# Define the pandemic period (when we don't want to calculate expected deaths)
pandemic.dates <- seq.Date(as.Date("2020-03-10"), as.Date("2020-12-31"), by = "day")


#---- Sub-analysis by Age Group #----

# The full dataset 'mort.dat' is also recorded by age groups, so let's see
# if there were any big differences in 2020 excess deaths by age group.
# Since the deputy only asked about adults, filter out anyone <18 years.
mort.dat <- filter(mort.dat, age != "<18")

# For age-specific rates of excess mortality, we'll use the same type of setup
# for demographic data, but this time we have a row age group's population
# in every year. This is a little different from analyzing specific causes of death
# since only residents in a given age group are considered at-risk of death in that
# category. Put another way, we want to calculate rates of death in each age group
# from the count level data that we have.

# Read in age group demographic data
demo.age.in <- read_csv("demo_by_year_by_age_2010-2020_MI.csv")

# Now we need to count how many deaths occurred for each age group, in each week
age.group.counts <- compute_counts(
  # Specify the line list
  dat = mort.dat,
  # Specify the daily demographic list
  demo = demo.age.in,
  # Specify the name of the column with date of death at the unit we want to analyze
  date = "isodate",
  # Specify the name of the column with age groups
  by = "age")

# Next, we're going to run an excess calculation model on each of the age groups.
# We could do this the hard way, by manually filtering the 'age.group.counts' table
# by each age group and running separate models, or we could use programming loops
# to accomplish the same goal.

# First, let's split 'age.group.counts' by age group. We'll use the 'split'
# function which will divide the full table by age group and store each as a data frame
# in a list.
age.group.ls <- split(age.group.counts,
                         # Define the factor (f) we want to split by
                         f = age.group.counts$age)

# Now we're going to use the 'lapply' function to apply the same process to each
# item in the list we just created.
weekly.xs.age <- lapply(
  age.group.ls, 
  # We're going to define a new function that operates on
  # each item in 'age.group.ls', which is represented
  # by the variable x
  function(x) {
    # Wrapping everything in 'return()' means that the results of the function
    # get returned and stored as an item in our output list (called 'weekly.xs.age')
    return(
      x %>%
        # We're running the same model as for the full dataset, only in each case
        # here, we've filtered to only include one specific age group at a time
        excess_model(exclude = pandemic.dates,
                     start = min(.$date),
                     end = max(.$date),
                     knots.per.year = 12,
                     include.trend = TRUE,
                     frequency = 52,
                     model = "quasipoisson",
                     alpha = 0.05,
                     keep.counts = TRUE)
    )
  })

# Just like before, this results in a pretty long output, so let's restructure. 
# We want to have a data frame where each row is a week and we have information for
# observed and expected death counts and rates and the confidence of these estimates.
# Since we have a list of results for each age group, we'll use 'lapply' again to
# do this restructuring.
weekly.xs.age.ts <- lapply(
  weekly.xs.age,
  function(x) {
    # The output of the 'excess_model' function is a list of results for 
    # each age group, but we only want the first few.
    x <- bind_cols(x[c("date", "observed", "expected", "fitted", "log_expected_se")]) %>%
      ## 'date' is the start of the week, 'observed' and 'expected' are counts
      ## of deaths that are either observed during the COVID-19 pandemic or
      ## expected based on 2010-2019 data, 'fitted' is the relative difference
      ## between observed and expected (f = (observed - expected) / expected),
      ## and 'se' is the standard error of that relative difference.
      # Let's use the standard error (and some algebra) to calculate confidence
      # intervals of the expect count of weekly deaths
      mutate(exp.l95 = exp(log(expected) - qnorm(1-(.05/2)) * log_expected_se),
             exp.u95 = exp(log(expected) + qnorm(1-(.05/2)) * log_expected_se))
  }
)

# Now let's plot a time series of the weekly counts of observed vs. expected
# # (and 95% confidence intervals) mortality. This time we're going to loop over
# two things though - (1) the weekly excess counts split up by age group and
# (2) a list of the age groups so we can include descriptive titles in the
# graph. Because we're using more than one list, we have to adapt our code to use
# 'mapply' (for multivariate apply) instead of 'lapply' like above. It's structured
# a little different, but the idea is generally the same. This time though, we can
# define more than one variable like you'll see below. 

# Plotting observed vs expected deaths from 1/1/2020 - 12/31/2020
xs.age.plots <- mapply(
  # We're going to define a function with two arguments, x and y, this time
  # We'll use 'x' to represent the 'weekly.age.ts' element and 'y' to represent
  # the age group used in titling and labeling the figure
  function(x, y) {
    # The time series data includes the entire time period but we only want to
    # plot the year 2020
    x <- x %>%
      filter(date > make_date(2020, 01, 01)) %>%
      # We're going to use 'ggplot' to make the figures, and it prefers long data
      # structures over wide
      pivot_longer(cols = c(observed:expected),
                   names_to = "class",
                   values_to = "value") %>%
      # Reordering and fixing labels for observed and expected categories
      mutate(class = factor(class, levels = c("observed", "expected"),
                            labels = c("Observed", "Expected")))
    
    # Plotting observed and expected (+95% CI) deaths
    return(
      # This line might look a little confusing because ggplot needs data for the
      # x and y axes, but 'x' is the data we're plotting and we're specifying inside
      # the aes() call what goes along the x- and y-axis.
      ggplot(x, aes(x = date, y = value, col = class)) +
        geom_line() +
        geom_ribbon(data = x %>% filter(class == "Expected"),
                    aes(ymin = exp.l95, ymax = exp.u95),
                    fill = NA, lty = 2) +
        scale_x_date(
          date_breaks = "1 month",
          date_minor_breaks = "1 week",
          date_labels = "%b %Y") +
        theme(axis.text.x = element_text(angle = 45, hjust = 1),
              panel.grid.minor = element_blank()) +
        xlab("Date") +
        ylab("Weekly Death Count") +
        labs(col = NULL,
             title = "Excess Mortality 2020",
             subtitle = paste(y, "Age Group", sep = " "))
    )
  },
  # Now we'll specify what 'x' and 'y' represent in the function above
  # 'x' will be the age group time series that we cleaned up
  x = weekly.xs.age.ts,
  # 'y' is used to generate plot titles and is the names of the elements of the
  # 'weekly.xs.age.ts' list (which are the names of the age groups).
  y = names(weekly.xs.age.ts),
  # Finally, we have to ask R to not wrap the results up in a list for us (the default)
  SIMPLIFY = FALSE
)

# Now that we have nice figures, let's save high-quality versions so we can share
# them in reports and presentations. With a single figure, we could write one
# line of code, but since we have lots of them here, let's use another 'mapply'
# loop to make things more efficient.
mapply(
  # We're going to define another function with two variables. 'x' will be the
  # figure we created and saved as 'xs.age.plots' and 'y' will be the filenames
  # we want to save as
  function(x, y) {
    ggsave(y, plot = x,
           # We can also specify what we want to figure to look like and its resolution
           # We'll make a 6.5x3 inch figure at 300 dots-per-inch (agood presentation
           # quality resolution)
           width = 6.5, height = 3, units = "in", dpi = 300)
  },
  x = xs.age.plots, 
  # We're going to use the names of the 'xs.age.plots' figures, but some of them
  # have '&' symbols and many of them have spaces which can be troublesome for
  # file naming sometimes, so we'll replace all of those with dashes and underscores
  # using the 'gsub' function. Since we want to replace two different characters,
  # we'll need to nest one 'gsub' within another.
  y = paste0("excess_",
             gsub(" ", "_",
                  gsub(" & ", "-", names(xs.age.plots))),
             "_deaths.png"))


# Now that we have a plot, let's make a table of observed, expected, and excess
# counts and rates for each age group Since we're looping over two lists, we'll use
# 'mapply' again where 'x' will refer to the weekly count data for each age group and
# 'y' will refer to the names of the age groups.
age.table <- mapply(function(x, y) {
  return(x %>%
           # We're going to run a new model, but this time we won't specify start
           # and end dates that we want to analyze. We'll still specify that we
           # want to exclude the pandemic from calculating our baseline expected rate.
           excess_model(exclude = pandemic.dates,
                        intervals = list(pandemic.dates),
                        knots.per.year = 12,
                        include.trend = FALSE,
                        model = "quasipoisson",
                        alpha = 0.05) %>%
           # Calculating standard error for confidence interval
           mutate(se = sd / sqrt(observed)) %>%
           # Calculating excess confidence interval
           mutate(excess.l95 = excess - qnorm(1-(.05/2)) * se,
                  excess.u95 = excess + qnorm(1-(.05/2)) * se) %>%
           # Calculating mortality ratio (observed / expected) & 95% CI
           mutate(mr = observed / expected,
                  mr.l95 = observed / (expected + qnorm(1-(.05/2)) * se),
                  mr.u95 = observed / (expected - qnorm(1-(.05/2)) * se)) %>%
           # Giving each row the name of the age group it represents
           mutate(age_group = y) %>%
           # Moving the cause column all the way to the left
           relocate(age_group) %>%
           # Calculating the excess rate
           mutate(xs_rate = obs_death_rate - exp_death_rate))
}, 
# Just like above, we'll specify what 'x' and 'y' stand for when looping though
x = age.group.ls,
y = names(age.group.ls),
SIMPLIFY = FALSE) %>%
  # The output is a list of data frames (each with a single row for age group
  # so we'll stack them all together into a single dataframe
  bind_rows()

# We can save this table as an Excel file so we can share it or reformat it
write.xlsx(age.table, "excess_deaths_by_age.xlsx", asTable = TRUE)

