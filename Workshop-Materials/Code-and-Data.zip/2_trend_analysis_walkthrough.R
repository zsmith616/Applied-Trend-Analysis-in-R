#----------------------------------------------------------------#
#               2025 CSTE Applied Trend Analysis in R            #
#                   Trend Analysis - Demonstration               #
# Authors: Johns Hopkins Surveillance and Outbreak Response Team #
#----------------------------------------------------------------#

#---- Setup #----

# List of packages used
pkgs <- c("excessmort", "tidyverse", "openxlsx")
# excessmort is the main package used for the excess calculation analysis
# tidyverse contains lots of useful data management and manipulation packages and functions
# openxlsx lets us save tables from R as .xlsx files that can be opened in Excel

# Installing any of the packages that you don't already have
install.packages(setdiff(pkgs, rownames(installed.packages())))

# Loading all the packages
lapply(pkgs, library, character.only = TRUE, quietly = TRUE, verbose = FALSE)

# We're going to analyze the weekly count data that we cleaned and set-up in the
# '1_data_prep_walkthrough.R' script. Since we saved it as a .rda file, let's read
# it in so we can use it here.
all.counts <- readRDS("weekly_count_data-all.rda")

# We'll also redefine the pandemic dates (just to be sure that they're in our
# working environment).
pandemic.dates <- seq.Date(as.Date("2020-03-10"),
                           as.Date("2020-12-31"),
                           by = "day")


#---- Calculating Overall Excess Mortality #----

# First, we fit a model to estimate expected weekly mortality and compare it
# to observed deaths to determine excess mortality over time.

weekly.xs.all <- all.counts %>%
  excess_model(
    # Exclude dates during the COVID-19 pandemic when computing expected counts
    exclude = pandemic.dates,
    
    # Define the range of data used to estimate the expected baseline.
    # Here, we use the full available dataset, but this can be adjusted if
    # needed (e.g., to remove early noisy data or recent incomplete data).
    start = min(.$date), # .$ refers to col in object left of pipe
    
    # Specifying the end of the model. Again, if there are reasons you wouldn't want
    # to use the full dataset (maybe you have low confidence in data completion for
    # recent timepoints) you can do so here.
    end = max(.$date),
    
    # Control the flexibility of the baseline model by setting the number of
    # spline knots per year. More knots allow the model to capture seasonal
    # variation better (up to a point - adding too many can risk overfitting the
    # prediction to your baseline and prevent you from meaningfully comparing past
    # observations to the present). 12 knots allows for monthly changes in baseline
    # prediction model, but more or fewer knots can be experimented with to create
    # the best fitting model to describe your baseline.
    knots.per.year = 12,
    
    # Specify whether you want a linear annual trend included in the prediction.
    # Not recommended if you have 5 or fewer years of baseline data. Since we have
    # plenty of baseline data, and it's reasonable for there to be longitudinal
    # trends in death rates over an 11-year period, we'll include an annual trend.
    include.trend = TRUE,
    
    # Specify the model type (quasi-Poisson helps account for overdispersion
    # in count data).
    model = "quasipoisson",
    
    # Set the significance level for confidence intervals.
    alpha = 0.05)

# Convert the model output (a list) into a more user-friendly dataframe format.
# We're only keeping key columns: date, observed deaths, expected deaths,
# and the standard error of the expected counts
weekly.xs.all <- bind_cols(weekly.xs.all[1:4]) %>%
  
  # Calculating 95% confidence intervals of expected deaths
  # Calculate the 95% confidence interval bounds for expected deaths using SE
  # Note: expected SE is on the log scale, so we exponentiate it before
  # applying the normal quantile.
  mutate(exp.l95 = expected + qnorm(0.025) * exp(log_expected_se),
         exp.u95 = expected + qnorm(0.975) * exp(log_expected_se))

# We can save this table as an Excel file so we can share it or reformat it
write.xlsx(weekly.xs.all, "weekly_excess_2010-2020.xlsx", asTable = TRUE)


#---- Preparing Data for Plotting #----

# Restructuring for plotting
# ggplot likes data formatted in a long format, (one column for values, one for
# category label) so we're stacking the observed and expected counts in a single
# column and adding a new label called 'class' to describe whether that number is
# an observed or expected count.

weekly.all.plotdat <- weekly.xs.all %>%
  
  # Filter to plot only data after Jan 1, 2020
  filter(date > make_date(2020, 01, 01)) %>%
  
  # Convert 'observed' and 'expected' columns into a single 'value' column,
  # with a new 'class' column labeling the type of value (Observed vs Expected).
  pivot_longer(cols = observed:expected,
               names_to = "class",
               values_to = "value") %>%
  
  # Renaming and reordering 'class' to make the legend of our plot look nicer
  mutate(class = factor(class, levels = c("observed", "expected"),
                        labels = c("Observed", "Expected")))


#---- Plotting Observed vs Expected Weekly Deaths ----#

# Plotting observed vs expected
ggplot(weekly.all.plotdat, aes(x = date, y = value, col = class)) +
  
  # Draw lines for observed and expected deaths
  geom_line() +
  
  # Draw a dotted curve to show the lower and upper 95% confidence interval
  # of the expected weekly values
  geom_ribbon(
    # We only want to plot the expected data, so we'll filter the full dataset
    data = weekly.all.plotdat %>% filter(class == "Expected"),
    # And a ribbon plot has two y values, a lower and an upper called 'ymin' and
    # 'ymax', respectively. We'll specify the name of the columns with those values.
    aes(ymin = exp.l95, ymax = exp.u95),
    # We don't want to paint a color in between the the upper and lower, so we'll
    # say the fill color is 'NA', and we want to use a dashed line so we'll specify
    # the linetype (lty)
    fill = NA, lty = 2) +
  
  # Format x-axis to show one label per month and minor ticks for each week
  scale_x_date(
    date_breaks = "1 month",
    date_minor_breaks = "1 week",
    date_labels = "%b %Y") +
  
  # Rotating x-axis labels and dropping minor grid lines in the plot panel
  theme(axis.text.x = element_text(angle = 45, hjust = 1),
        panel.grid.minor = element_blank()) +
  
  # Label axes
  xlab("Date") +
  ylab("Weekly Death Count") +
  
  # Dropping the legend title (since there's only one type of presented data)
  labs(col = NULL)


#---- Calculating Total Excess Deaths Over Specific Periods ----#

# This section computes the cumulative excess deaths across entire time
# intervals (not weekly). It's useful for summarizing total excess during
# specific periods of interest.

overall.excess <- all.counts %>%
  excess_model(
    
    # Again exclude pandemic dates from the baseline fitting
    exclude = pandemic.dates,
    
    # Instead of specifying a start and stop date, we can specify a period(s) of
    # interest where we want to specifically calculate excess mortality. These
    # periods always have to be included as a list (even if there's only 1).
    intervals = list(
      
      # Full pandemic period
      pandemic.dates,
      
      # Year 1 of the pandemic
      seq(make_date(2020, 03, 10), make_date(2020, 12, 31), by = "day")),
    
    # Same model settings as before
    knots.per.year = 12,
    include.trend = FALSE,
    model = "quasipoisson",
    alpha = 0.05)

# We can save this table as an Excel file so we can share it or reformat it
write.xlsx(overall.excess, "overall_excess_2010-2020.xlsx", asTable = TRUE)