#----------------------------------------------------------------#
#               2025 CSTE Applied Trend Analysis in R            #
#          Subgroup Analysis Strategies - Guided Practice        #
# Authors: Johns Hopkins Surveillance and Outbreak Response Team #
#----------------------------------------------------------------#

# In this guided practice session, we will ask you to use what you learned in
# the R walkthrough and apply it to a slightly altered scenario to orient
# to the code. We will leave questions and blanks (____) in the code that
# you will have to fill in to complete the actions. Refer to the
# R walkthrough scripts for guidance.


#---- Setup #----

# List of package names as characters
pkgs <- c("tidyverse", "ISOweek", "excessmort", "ggpubr", "openxlsx")

# Installing any of the packages that you don't already have
install.packages(setdiff(pkgs, rownames(installed.packages())))

# Loading all the packages
lapply(pkgs, library, character.only = TRUE, quietly = TRUE, verbose = FALSE)

# Read in mortality data set
mort.dat <- read_csv("linelist_2010-2020_mi.csv") %>%
  mutate(isoweek = paste0(isoyear(date), "-W", sprintf("%02d", isoweek(date)),"-1")) %>%
  mutate(isodate = ISOweek2date(isoweek)) %>%
  select(-date) %>%
  filter(isoweek != "2009-W53-1" & isoweek != "2020-W53-1")

# Define the pandemic period (when we don't want to calculate expected deaths)
pandemic.dates <- seq.Date(as.Date("2020-03-10"), as.Date("2020-12-31"), by = "day")


#---- Sub-analysis by County #----

# The full dataset 'mort.dat' is also recorded at the county level, so let's see
# if there were any big differences in 2020 excess deaths by county

# For county-specific rates of excess mortality, we'll use the same type of setup
# for demographic data, but this time we have a row for every county's population
# in every year. This is a little different from analyzing specific causes of death
# since only residents in a given county are considered at-risk of death in that
# category. Put another way, we want to calculate rates of death in each county
# from the count level data that we have.

# Read in county-level demographic data
demo.county.in <- read_csv("demo_by_year_by_county_2010-2020_MI.csv")

# But since there are 83 counties in Michigan, let's make things a little easier
# on ourselves and select four counties to look at. How about two urban and two
# rural? Let's look at Wayne County (Detroit), Kent County (Grand Rapids),
# Marquette (in the Upper Pensinsula), and Lapeer (outside Detroit).

### Question: Filter to these counties
mort.dat.co <- mort.dat %>%
  filter(county %in% c("Wayne County, MI", ____))

### Question: Filter the demographic data the same way
demo.county.in.sub <- demo.county.in %>%
  
  # We need to take that table of annual population by county and create a long
  # dataframe with daily population.
  ### Question: How should you set this code up? What type of extrapolation do
  ### you think should be performed?
  demo.county <- approx_demographics(demo.county.in.sub,
                                     first_day = min(mort.dat$isodate),
                                     last_day = ,
                                     by = "county",
                                     extrapolation.type = )

# Count how many deaths occurred in each county, each week
### Question: How should the 'compute_counts()' function be completed to count
### weekly deaths in each county?
county.counts <- compute_counts()

### Question: How can we 'split' the counts of weekly deaths into a list of dataframes
### with a separate dataframe for each county?
county.counts.ls <-
  
  # Run the excess model function on each item in the list using 'lapply'
  weekly.xs.county <- lapply(
    county.counts.ls,
    # Define a new function where the variable 'x' will stand in for each county's
    # weekly counts of deaths
    function(x) {
      return(
        x %>%
          ### Question: How would you set up the 'excess_model' function?
          excess_model(exclude = ,
                       start = min(.$date),
                       end = max(.$date),
          )
      )
    })

### Question: If we want to restructure the model ouput to plot a time series
### of observed vs. expected deaths (including a 95% confidence interval of the
### expected weekly count), how would you create an 'lapply' loop to drop the
### columns we don't need and calculate a 95% CI?
weekly.county.ts <- lapply(
  weekly.xs.county,
  # Define a function where the variable 'x' will stand in for each county's
  # excess model output (stored in the 'weekly.xs.county' object)
  function(x) {
    
  }
)

# Efficiently plot excess death by county using an 'mapply' loop to loop over
# the time series data for each county created in the step above and the names of
# each county
xs.county.plots <- mapply(
  # Define a function where the variable 'x' will stand in for each county's
  # times series of observed and expected deaths and 'y' will stand in for the
  # names of each corresponding county
  function(x, y) {
    x <- x %>%
      ### Question: filter for only dates in 2020
      filter() %>%
      ### Question: Restructure the data from wide to long, creating a new variable
      ### called 'class' that describes whether the value is an observed or
      ### expected weekly count.
      pivot_longer(cols = ,
                   names_to = ,
      ) %>%
      mutate(class = factor(class, levels = c("observed", "expected"),
                            labels = c("Observed", "Expected")))
    
    return(
      ### Question: Create a time series line plot with a ribbon plot of the upper
      ### and lower 95% confidence interval
      ggplot(x, aes(x = , y = , col = )) +
        geom_line() +
        geom_ribbon() +
        +
        labs(col = NULL,
             title = "Excess Mortality 2020",
             subtitle = y)
    )
  },
  ### Question: Define what the variables 'x' and 'y' refer to in your function.
  x = ,
  y = ,
  SIMPLIFY = FALSE
)

### Question: Which county experienced the greatest relative and/or absolute excess
### mortality during the first wave of COVID-19? What about the during the B.1.1.7
### "Alpha" wave in late 2020?

# Save the figures for each county
mapply(
  function(x, y) {
    ggsave(y, plot = x,
           width = 6.5, height = 3, units = "in", dpi = 300)
  },
  x = xs.county.plots,
  y = paste0("excess_",
             gsub(" ", "_",
                  gsub(" & ", "-", names(xs.county.plots))),
             "_deaths.png"))

# Create a table of statistics for each county
county.table <- mapply(
  # Define a function where the variable 'x' refers to weekly counts of deaths by
  # county and the variable 'y' refers to the names of each corresponding county.
  function(x, y) {
    
    return(
      ### Question: Calculate excess mortality in 2020 for each county
      x %>%
        ### Question: Run the 'excess_model()'
        ### Question: Calculate standard error
        ### Question: Use the standard error you calculated to calculate confidence
        ### intervals of excess mortality
        ### Question: Calculate mortality ratios and confidence intervals
        ### Question: Calculate the rate of excess mortality
  },
  x = ,
  y = ,
  SIMPLIFY = FALSE) %>%
      # Take each county's output and store it as a row in a new dataframe
      bind_rows()
    
    ### Question: Which county(ies) experience significant excess mortality during
    ### the COVID-19 pandemic in 2020?
    ### Question: How many more people died during the 2020 COVID-19
    ### pandemic than was expected in Lapeer County?
    
    ### Question: Save the table as an Excel file
    